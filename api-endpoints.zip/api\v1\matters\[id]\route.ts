import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { withApiAuth, successResponse, errorResponse, notFoundResponse } from '@/lib/api-auth';

export const dynamic = 'force-dynamic';

/**
 * GET /api/v1/matters/:id
 * Get a single matter by ID
 */
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    const { id } = await params;
    const { auth, error } = await withApiAuth(request);
    if (error) return error;

    try {
        const matter = await prisma.matter.findFirst({
            where: {
                id,
                workspaceId: auth!.workspaceId,
            },
            include: {
                client: { select: { id: true, name: true, email: true } },
                lawyers: {
                    include: {
                        lawyer: { select: { id: true, name: true, email: true } }
                    }
                },
                briefs: {
                    select: {
                        id: true,
                        briefNumber: true,
                        name: true,
                        status: true,
                    },
                },
            },
        });

        if (!matter) {
            return notFoundResponse('Matter');
        }

        return successResponse(matter);

    } catch (err) {
        console.error('Error fetching matter:', err);
        return errorResponse('SERVER_ERROR', 'Failed to fetch matter', 500);
    }
}

/**
 * PATCH /api/v1/matters/:id
 * Update a matter
 */
export async function PATCH(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    const { id } = await params;
    const { auth, error } = await withApiAuth(request);
    if (error) return error;

    try {
        const existing = await prisma.matter.findFirst({
            where: {
                id,
                workspaceId: auth!.workspaceId,
            },
        });

        if (!existing) {
            return notFoundResponse('Matter');
        }

        const body = await request.json();
        const { name, status, court, judge, description, nextCourtDate, lawyerAssociations } = body;

        const updateData: any = {};
        if (name !== undefined) updateData.name = name;
        if (status !== undefined) updateData.status = status;
        if (court !== undefined) updateData.court = court;
        if (judge !== undefined) updateData.judge = judge;
        if (description !== undefined) updateData.description = description;
        if (nextCourtDate !== undefined) updateData.nextCourtDate = nextCourtDate ? new Date(nextCourtDate) : null;
        if (lawyerAssociations !== undefined) {
            updateData.lawyers = {
                deleteMany: {},
                create: lawyerAssociations.map((assoc: any) => ({
                    lawyerId: assoc.lawyerId,
                    role: assoc.role,
                    isAppearing: assoc.isAppearing || false
                }))
            };
        }

        const matter = await prisma.matter.update({
            where: { id },
            data: updateData,
            include: {
                client: { select: { id: true, name: true } },
                lawyers: {
                    include: {
                        lawyer: { select: { id: true, name: true } }
                    }
                },
            },
        });

        return successResponse(matter);

    } catch (err) {
        console.error('Error updating matter:', err);
        return errorResponse('SERVER_ERROR', 'Failed to update matter', 500);
    }
}

/**
 * DELETE /api/v1/matters/:id
 * Delete a matter
 */
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    const { id } = await params;
    const { auth, error } = await withApiAuth(request);
    if (error) return error;

    if (!['owner', 'partner'].includes(auth!.role)) {
        return errorResponse('FORBIDDEN', 'Only owners and partners can delete matters', 403);
    }

    try {
        const matter = await prisma.matter.findFirst({
            where: {
                id,
                workspaceId: auth!.workspaceId,
            },
        });

        if (!matter) {
            return notFoundResponse('Matter');
        }

        await prisma.matter.delete({
            where: { id },
        });

        return successResponse({ deleted: true });

    } catch (err) {
        console.error('Error deleting matter:', err);
        return errorResponse('SERVER_ERROR', 'Failed to delete matter', 500);
    }
}
